(* Name: <your name> *)
(* Course: UVM CS 225 Spring 2018 - Darais *)
(* HW: EC1 *)

open Util
open StringSetMap

(* The Assignment:
 * 
 * Fill in the `raise TODO` parts of the code:
 * - 08 cases in the `subst_r` function
 * - 26 cases in the `step` function
 *
 * Passing all of the tests does not guarantee 100%. You may want to write some
 * tests of your own.
 *)

(* Types.
 *
 * τ ∈ ty ⩴ bool
 *        | τ ⇒ τ
 *        | empty
 *        | unit
 *        | τ + τ
 *        | τ × τ
 *)
type ty =
  | Bool
  | Fun of ty * ty
  (* New types *)
  | Empty
  | Unit
  | Sum of ty * ty
  | Prod of ty * ty
[@@deriving show {with_path = false}]

(* Expressions.
 *
 * e ∈ exp ⩴ true | false | if(e){e}{e}
 *         | x | λx:τ.e | e e
 *         | absurd(e) as τ
 *         | •
 *         | inl(e) as τ | inr(e) as τ
 *         | case(e){x.e}{x.e}
 *         | ⟨e,e⟩ | projl(e) | projr(e)
 *)
type exp =
  | True
  | False
  | If of exp * exp * exp
  | Var of string
  | Lam of string * ty * exp
  | App of exp * exp
  (* New expressions *)
  | Absurd of exp * ty
  | Bullet
  | Inl of exp * ty
  | Inr of exp * ty
  | Case of exp * (string * exp) * (string * exp)
  | Pair of exp * exp
  | Projl of exp
  | Projr of exp
[@@deriving show {with_path = false}]

(* Free variables metafunction.
 *
 * FV ∈ exp → 𝒫(var)
 * FV(true) ≔ {}
 * FV(false) ≔ {}
 * FV(if(e₁){e₂}{e₃}) ≔ FV(e₁) ∪ FV(e₂) ∪ FV(e₃)
 * FV(x) ≔ ❴x❵
 * FV(λx:τ.e) ≔ FV(e) \ {x}
 * FV(e₁ e₂) ≔ FV(e₁) ∪ FV(e₂)
 * FV(absurd(e) as τ) ≔ FV(e)
 * FV(•) ≔ ❴❵
 * FV(inl(e) as τ) ≔ FV(e)
 * FV(inr(e) as τ) ≔ FV(e)
 * FV(case(e₁){x₂.e₂}{x₃.e₃}) ≔
 *   FV(e₁) ∪ (FV(e₂) \ {x₂}) ∪ (FV(e₃) \ {x₃})
 * FV(⟨e₁,e₂⟩) ≔ FV(e₁) ∪ FV(e₂)
 * FV(projl(e)) ≔ FV(e)
 * FV(projr(e)) ≔ FV(e)
 *)
let rec free_vars (e0 : exp) : string_set = match e0 with
  | True -> StringSet.empty
  | False -> StringSet.empty
  | If(e1,e2,e3) ->
      StringSet.union (StringSet.union (free_vars e1) (free_vars e2))
      (free_vars e3)
  | Var(x) -> StringSet.of_list [x]
  | Lam(x,t,e) -> StringSet.remove x (free_vars e)
  | App(e1,e2) -> StringSet.union (free_vars e1) (free_vars e2)
  (* New cases *)
  | Absurd(e',t) -> free_vars e'
  | Bullet -> StringSet.empty
  | Inl(e,t) -> free_vars e
  | Inr(e,t) -> free_vars e
  | Case(e1,(x2,e2),(x3,e3)) ->
      StringSet.union (StringSet.remove x2 (free_vars e2))
                      (StringSet.remove x3 (free_vars e3))
  | Pair(e1,e2) -> StringSet.union (free_vars e1) (free_vars e2)
  | Projl(e) -> free_vars e
  | Projr(e) -> free_vars e

(* Enforces global uniqueness of variables. *)
let unique_vars (e : exp) : exp =
  let new_var (iO : int option) (x : string) : string = match iO with
      | None -> x
      | Some(i) -> x ^ string_of_int i
  in
  let next_var (iO : int option) : int option = match iO with
      | None -> Some(1)
      | Some(i) -> Some(i+1)
  in
  let rec rename_var_r
    (iO : int option)
    (x : string)
    (g : string_set)
    : string * string_set =
      let x' = new_var iO x in
      if StringSet.mem x' g
      then rename_var_r (next_var iO) x g
      else (x',StringSet.add x' g)
  in
  let rename_var = rename_var_r None in
  let rec unique_vars_r
    (e0 : exp)
    (env : string string_map)
    (g : string_set)
    : exp * string_set =
      match e0 with
      | True -> (True,g)
      | False -> (False,g)
      | If(e1,e2,e3) ->
          let (e1',g'1) = unique_vars_r e1 env g in
          let (e2',g'2) = unique_vars_r e2 env g'1 in
          let (e3',g'3) = unique_vars_r e3 env g'2 in
          (If(e1',e2',e3'),g'3)
      | Var(x) -> (Var(StringMap.find x env),g)
      | Lam(x,t,e) ->
          let (x',g') = rename_var x g in
          let (e',g'') = unique_vars_r e (StringMap.add x x' env) g' in
          (Lam(x',t,e'),g'')
      | App(e1,e2) ->
          let (e1',g') = unique_vars_r e1 env g in
          let (e2',g'') = unique_vars_r e2 env g' in
          (App(e1',e2'),g'')
      (* New cases *)
      | Absurd(e,t) ->
          let (e',g') = unique_vars_r e env g in
          (Absurd(e',t),g')
      | Bullet -> (Bullet,g)
      | Inl(e,t) ->
          let (e',g') = unique_vars_r e env g in
          (Inl(e',t),g')
      | Inr(e,t) ->
          let (e',g') = unique_vars_r e env g in
          (Inr(e',t),g')
      | Case(e1,(x2,e2),(x3,e3)) ->
          let (e1',g'1) = unique_vars_r e1 env g in
          let (x2',g'2) = rename_var x2 g'1 in
          let (e2',g'3) = unique_vars_r e2 (StringMap.add x2 x2' env) g'2 in
          let (x3',g'4) = rename_var x3 g'3 in
          let (e3',g'5) = unique_vars_r e3 (StringMap.add x3 x3' env) g'4 in
          (Case(e1',(x2',e2'),(x3',e3')),g'5)
      | Pair(e1,e2) ->
          let (e1',g') = unique_vars_r e1 env g in
          let (e2',g'') = unique_vars_r e2 env g' in
          (Pair(e1',e2'),g'')
      | Projl(e) ->
          let (e',g') = unique_vars_r e env g in
          (Projl(e'),g')
      | Projr(e) ->
          let (e',g') = unique_vars_r e env g in
          (Projr(e'),g')
  in
  let initial_env (ss : string_set) =
    List.fold_right (fun x -> StringMap.add x x) (StringSet.elements ss) StringMap.empty
  in
  let fvs : string_set = free_vars e in
  let (e',_) = unique_vars_r e (initial_env fvs) fvs in
  e'

(* Substitution metafunction.
 *
 * [_↦_]_ ∈ var × exp × exp → exp
 * [x↦e₂]true ≔ true
 * [x↦e₂]false ≔ false
 * [x↦e₂](if(e₁₁){e₁₂}{e₁₃}) ≔ if([x↦e₂]e₁₁){[x↦e₂]e₁₂}{[x↦e₂]e₁₃}
 * [x↦e₂]y ≔ e₂    if x=y
 * [x↦e₂]y ≔ y     if x≠y
 * [x↦e₂](λx.e₁) ≔ λx.[x↦e₂]e₁
 * [x↦e₂](e₁₁ e₁₂) ≔ [x↦e₂]e₁₁ [x↦e₂]e₁₂
 * [x↦e₂](absurd(e₁)) ≔ absurd([x↦e₂]e₁)
 * [x↦e₂](•) ≔ •
 * [x↦e₂](inl(e₁)) ≔ inl([x↦e₂]e₁)
 * [x↦e₂](inr(e₁)) ≔ inr([x↦e₂]e₁)
 * [x↦e₂](case(e₁₁){x₂.e₁₂}{x₃.e₁₃}) ≔
 *   case([x↦e₂]e₁₁){x₂.[x↦e₂]e₁₂}{x₃.[x↦e₂]e₁₃}
 * [x↦e₂](⟨e₁₁,e₁₂⟩) ≔ ⟨[x↦e₂]e₁₁,[x↦e₂]e₁₃⟩
 * [x↦e₂](projl(e₁)) ≔ projl([x↦e₂]e₁)
 * [x↦e₂](projr(e₁)) ≔ projr([x↦e₂]e₁)
 *)
let rec subst_r (x : string) (e2 : exp) (e10 : exp) : exp = match e10 with
  | True -> True
  | False -> False
  | If(e11,e12,e13) -> If(subst_r x e2 e11,subst_r x e2 e12,subst_r x e2 e13)
  | Var(y) -> if x = y then e2 else Var(y)
  | Lam(y,t,e1) -> Lam(y,t,subst_r x e2 e1)
  | App(t11,t12) -> App(subst_r x e2 t11,subst_r x e2 t12)
  (* New cases *)
  | Absurd(e1,t) -> raise TODO
  | Bullet -> raise TODO
  | Inl(e1,t) -> raise TODO
  | Inr(e1,t) -> raise TODO
  | Case(e11,(x2,e12),(x3,e13)) -> raise TODO
  | Pair(e11,e12) -> raise TODO
  | Projl(e1) -> raise TODO
  | Projr(e1) -> raise TODO

let subst (x : string) (t : ty) (e2 : exp) (e1 : exp) : exp =
  match unique_vars (App(Lam(x,t,e1),e2)) with
  | App(Lam(x',_,e1'),e2') -> subst_r x' e2' e1'
  | _ -> raise IMPOSSIBLE

(* Values.
 *
 * v ∈ val ⩴ true | false
 *         | λx:τ.e
 *         | •
 *         | inl(v) | inr(v)
 *         | ⟨v,v⟩
 *)
type value =
  | VTrue
  | VFalse
  | VLam of string * ty * exp
  | VBullet
  | VInl of value * ty
  | VInr of value * ty
  | VPair of value * value
[@@deriving show {with_path = false}]

let rec exp_of_value (v0 : value) : exp = match v0 with
  | VTrue -> True
  | VFalse -> False
  | VLam(x,t,e) -> Lam(x,t,e)
  | VBullet -> Bullet
  | VInl(v,t) -> Inl(exp_of_value v,t)
  | VInr(v,t) -> Inr(exp_of_value v,t)
  | VPair(v1,v2) -> Pair(exp_of_value v1,exp_of_value v2)

type result =
  | Val of value
  | Next of exp
  | Stuck
[@@deriving show {with_path = false}]

(* Small-step semantics relation encoded as a metafunction.
 * step(e) = Val(v) means e is syntactically the value v
 * step(e) = Next(e') means e —→ e'
 * step(e) = Stuck means there is no e' s.t. e —→ e'
 *)
let rec step (e0 : exp) : result = match e0 with
  (* true  ∈  val *)
  | True -> Val(VTrue)
  (* false  ∈  val *)
  | False -> Val(VFalse)
  | If(e1,e2,e3) -> begin match step e1 with
    (* ——————————————————————
     * if(true){e₂}{e₃} —→ e₂
     *)
    | Val(VTrue) -> Next(e2)
    (* ———————————————————————
     * if(false){e₂}{e₃} —→ e₃
     *)
    | Val(VFalse) -> Next(e3)
    | Val(_) -> Stuck
    (*             e₁ —→ e₁′
     * —————————————————————————————————
     * if(e₁){e₂}{e₃} —→ if(e₁′){e₂}{e₃}
     *)
    | Next(e1') -> Next(If(e1',e2,e3))
    | Stuck -> Stuck
    end
  | Var(_) -> Stuck
  (* λx:τ.e  ∈  val *)
  | Lam(x,t,e) -> Val(VLam(x,t,e))
  | App(e1,e2) -> begin match step e1 with
    | Val(v1) -> begin match step e2 with
      | Val(v2) -> begin match v1 with
        (* —————————————————————(β)
         * (λx:τ.e)v —→ [x ↦ v]e
         *)
        | VLam(x,t,e) -> Next(subst x t (exp_of_value v2) e)
        | _ -> Stuck
        end
      (*   e₂ —→ e₂′
       * —————————————
       * v₁ e₂ —→ v₁ e₂′
       *)
      | Next(e2') -> Next(App(e1,e2'))
      | Stuck -> Stuck
      end
    (*    e₁ —→ e₁′
     * ———————————————
     * e₁ e₂ —→ e₁′ e₂
     *)
    | Next(e1') -> Next(App(e1',e2))
    | Stuck -> Stuck
    end
  (* New cases *)
  | Absurd(_,_) -> raise TODO
  (* •  ∈  val *)
  | Bullet -> raise TODO
  | Inl(e,t) -> begin match step e with
    (* inl(v)  ∈  val *)
    | Val(v) -> raise TODO
    (*      e —→ e′
     * —————————————————
     * inl(e) —→ inl(e′)
     *)
    | Next(e') -> raise TODO
    | Stuck -> raise TODO
    end
  | Inr(e,t) -> begin match step e with
    (* inr(v)  ∈  val *)
    | Val(v) -> raise TODO
    (*      e —→ e′
     * —————————————————
     * inr(e) —→ inr(e′)
     *)
    | Next(e') -> raise TODO
    | Stuck -> raise TODO
    end
  | Case(e1,(x2,e2),(x3,e3)) -> begin match step e1 with
    (* ————————————————————————————————————————
     * case(inl(v)){x₂.e₂}{x₃.e₃} —→ [x₂ ↦ v]e₂
     *)
    | Val(VInl(v,t)) -> raise TODO
    (* ————————————————————————————————————————
     * case(inr(v)){x₂.e₂}{x₃.e₃} —→ [x₃ ↦ v]e₃
     *)
    | Val(VInr(v,t)) -> raise TODO
    | Val(_) -> raise TODO
    (*                     e₁ —→ e₁′
     * —————————————————————————————————————————————————
     * case(e₁){x₂.e₂}{x₃.e₃} —→ case(e₁′){x₂.e₂}{x₃.e₃}
     *)
    | Next(e1') -> raise TODO
    | Stuck -> raise TODO
    end
  | Pair(e1,e2) -> begin match step e1 with
    | Val(v1) -> begin match step e2 with
      (* ⟨v₁,v₂⟩  ∈  val *)
      | Val(v2) -> raise TODO
      (*      e₂ —→ e₂′
       * ———————————————————
       * ⟨v₁,e₂⟩ —→ ⟨v₁,e₂′⟩
       *)
      | Next(e2') -> raise TODO
      | Stuck -> raise TODO
      end
    (*      e₁ —→ e₁′
     * ———————————————————
     * ⟨e₁,e₂⟩ —→ ⟨e₁′,e₂⟩
     *)
    | Next(e1') -> raise TODO
    | Stuck -> raise TODO
    end
  | Projl(e) -> begin match step e with
    (* ————————————————————
     * projl(⟨v₁,v₂⟩) —→ v₁
     *)
    | Val(VPair(v1,v2)) -> raise TODO
    | Val(_) -> raise TODO
    (*        e —→ e′
     * —————————————————————
     * projl(e) —→ projl(e′)
     *)
    | Next(e') -> raise TODO
    | Stuck -> raise TODO
    end
  | Projr(e) -> begin match step e with
    (* ————————————————————
     * projr(⟨v₁,v₂⟩) —→ v₂
     *)
    | Val(VPair(v1,v2)) -> raise TODO
    | Val(_) -> raise TODO
    (*        e —→ e′
     * —————————————————————
     * projr(e) —→ projr(e′)
     *)
    | Next(e') -> raise TODO
    | Stuck -> raise TODO
    end

(* The reflexive transitive closure of the small-step semantics relation *)
let rec step_star (e : exp) : exp = match step e with
  | Val(v) -> exp_of_value v
  | Next(e') -> step_star e'
  | Stuck -> e

(* TESTING SECTION *)

type test_result = TestPassed | TestFailed | TestTodo

type test_block = 
  TestBlock : string * ('a * 'b) list * ('a -> 'b) * ('a -> string) * ('b -> string) -> test_block

let _SHOW_PASSED_TESTS : bool = true

let _ =
  let subst_tests : test_block =
    TestBlock
    ( "SUBST"
    , [ ("x" , Var("y") , Absurd(Var("x"),Unit)                               ) , Absurd(Var("y"),Unit)
      ; ("x" , Var("y") , Bullet                                              ) , Bullet
      ; ("x" , Var("y") , Inl(Var("x"),Sum(Bool,Bool))                        ) , Inl(Var("y"),Sum(Bool,Bool))
      ; ("x" , Var("y") , Inr(Var("x"),Sum(Bool,Bool))                        ) , Inr(Var("y"),Sum(Bool,Bool))
      ; ("x" , Var("y") , Case(Inl(Bullet,Sum(Unit,Unit)),("a",Var("x")),("b",Var("b"))) )
                        , Case(Inl(Bullet,Sum(Unit,Unit)),("a",Var("y")),("b",Var("b")))
      ; ("x" , Var("y") , Pair(Var("x"),Var("x"))                             ) , Pair(Var("y"),Var("y"))
      ; ("x" , Var("y") , Projl(Pair(Var("x"),Var("z")))                      ) , Projl(Pair(Var("y"),Var("z")))
      ; ("x" , Var("y") , Projr(Pair(Var("x"),Var("z")))                      ) , Projr(Pair(Var("y"),Var("z")))
      ]
    , (fun (x,e2,e1) -> subst x Unit e2 e1)
    , (fun (x,e2,e1) -> "[" ^ x ^ " |-> " ^ show_exp e2 ^ "](" ^ show_exp e1 ^ ")")
    , show_exp
    )
  in
  let step_tests : test_block =
    TestBlock
    ( "STEP"
    , [ Absurd(Var("x"),Unit)                                       , Stuck
      ; Bullet                                                      , Val(VBullet)
      ; Inl(Bullet,Sum(Unit,Unit))                                  , Val(VInl(VBullet,Sum(Unit,Unit)))
      ; Inl(If(True,False,True),Sum(Bool,Bool))                     , Next(Inl(False,Sum(Bool,Bool)))
      ; Inl(If(Bullet,False,True),Sum(Bool,Bool))                   , Stuck
      ; Inr(Bullet,Sum(Unit,Unit))                                  , Val(VInr(VBullet,Sum(Unit,Unit)))
      ; Inr(If(True,False,True),Sum(Bool,Bool))                     , Next(Inr(False,Sum(Bool,Bool)))
      ; Inr(If(Bullet,False,True),Sum(Bool,Bool))                   , Stuck
      ; Case(Inl(Bullet,Sum(Unit,Bool)),("x",Var("x")),("y",Var("y")))
      , Next(Bullet)
      ; Case(Inr(True,Sum(Unit,Bool)),("x",Var("x")),("y",Var("y")))
      , Next(True)
      ; Case(Bullet,("x",Var("x")),("y",Var("y")))
      , Stuck
      ; Case(If(True,Inl(Bullet,Sum(Unit,Bool)),Inr(True,Sum(Unit,Bool)))
           ,("x",Var("x"))
           ,("y",Var("y")))
      , Next(Case(Inl(Bullet,Sum(Unit,Bool)),("x",Var("x")),("y",Var("y"))))
      ; Case(If(Bullet,Inl(Bullet,Sum(Unit,Bool)),Inr(True,Sum(Unit,Bool)))
           ,("x",Var("x"))
           ,("y",Var("y")))
      , Stuck
      ; Pair(Bullet,True)                                           , Val(VPair(VBullet,VTrue))
      ; Pair(Bullet,If(True,False,True))                            , Next(Pair(Bullet,False))
      ; Pair(Bullet,If(Bullet,False,True))                          , Stuck
      ; Pair(If(True,Bullet,Bullet),True)                           , Next(Pair(Bullet,True))
      ; Pair(If(Bullet,Bullet,Bullet),True)                         , Stuck
      ; Projl(Pair(True,Bullet))                                    , Val(VTrue)
      ; Projl(True)                                                 , Stuck
      ; Projl(If(True,Pair(True,Bullet),Pair(False,Bullet)))        , Next(Projl(Pair(True,Bullet)))
      ; Projl(If(Bullet,Pair(True,Bullet),Pair(False,Bullet)))      , Stuck
      ; Projr(Pair(True,Bullet))                                    , Val(VBullet)
      ; Projr(True)                                                 , Stuck
      ; Projr(If(True,Pair(True,Bullet),Pair(False,Bullet)))        , Next(Projr(Pair(True,Bullet)))
      ; Projr(If(Bullet,Pair(True,Bullet),Pair(False,Bullet)))      , Stuck
      ]
    , step 
    , show_exp
    , show_result
    )
  in
  let (passed,failed,todo) = 
    List.fold_left begin fun (passed,failed,todo) (TestBlock(name,test_cases,run_test,show_input,show_output)) ->
      print_endline ("<" ^ name ^ ">") ;
      List.fold_left begin fun (passed,failed,todo) (input,expected) ->
        try
          let result = run_test input in
          if result = expected
          then begin
            if _SHOW_PASSED_TESTS then begin
              print_endline ("test    : " ^ show_input input) ;
              print_endline ("expected: " ^ show_output expected) ;
              print_endline "PASSED"
            end ;
            (passed+1,failed,todo)
          end else begin
            print_endline ("test    : " ^ show_input input) ;
            print_endline ("expected: " ^ show_output expected) ;
            print_endline ("output  : " ^ show_output result) ;
            print_endline "FAILED" ;
            (passed,failed+1,todo)
          end
        with TODO -> 
          print_endline ("test    : " ^ show_input input) ;
          print_endline ("expected: " ^ show_output expected) ;
          print_endline "TODO" ;
          (passed,failed,todo+1)
      end (passed,failed,todo) test_cases
    end (0,0,0) [subst_tests;step_tests]
  in
  print_endline "" ;
  print_endline ("TESTS PASSED: " ^ string_of_int passed) ;
  print_endline ("TESTS FAILED: " ^ string_of_int failed) ;
  print_endline ("TESTS TODO: " ^ string_of_int todo)

(* Name: <your name> *)

